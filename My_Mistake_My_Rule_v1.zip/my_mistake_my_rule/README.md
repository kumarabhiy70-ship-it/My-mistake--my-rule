# My Mistake My Rule

A Flutter starter app for PDF selection and PDF combining.

## What is included
- Professional app name: My Mistake My Rule
- Select one or more PDFs
- Combine selected PDFs
- Save the combined PDF
- My Rule description shown in the app
- No Android system-setting changes

## Important
This is the first working prototype source. The automatic "My Rule" page classification
(teacher-taught vs Telegram/homework/Thank You/extra) is not yet implemented because
reliable classification needs a page preview/OCR layer and user confirmation.

## Run
1. Install Flutter on a computer.
2. Extract this project.
3. Run `flutter pub get`
4. Run `flutter run`
5. For an Android APK: `flutter build apk --release`

The resulting APK is produced by Flutter on the computer/Android build environment.
