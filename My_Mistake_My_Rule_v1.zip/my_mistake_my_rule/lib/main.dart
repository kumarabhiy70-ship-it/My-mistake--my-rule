import 'dart:io';
import 'dart:typed_data';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

void main() => runApp(const MyRuleApp());

class MyRuleApp extends StatelessWidget {
  const MyRuleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Mistake My Rule',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<File> _pdfs = [];
  bool _busy = false;

  Future<void> pickPdfs() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      allowMultiple: true,
    );
    if (result == null) return;
    setState(() {
      _pdfs
        ..clear()
        ..addAll(result.paths.whereType<String>().map(File.new));
    });
  }

  Future<void> combinePdfs() async {
    if (_pdfs.isEmpty) return;
    setState(() => _busy = true);
    try {
      final out = PdfDocument();
      for (final file in _pdfs) {
        final bytes = await file.readAsBytes();
        final doc = PdfDocument(inputBytes: bytes);
        for (var i = 0; i < doc.pages.count; i++) {
          final page = out.pages.add();
          final template = doc.pages[i].createTemplate();
          page.graphics.drawPdfTemplate(template, Offset.zero);
        }
        doc.dispose();
      }
      final bytes = Uint8List.fromList(await out.save());
      out.dispose();

      final savePath = await FilePicker.platform.saveFile(
        dialogTitle: 'Save combined PDF',
        fileName: 'My_Rule_Combined.pdf',
        type: FileType.custom,
        allowedExtensions: ['pdf'],
      );
      if (savePath != null) {
        await File(savePath).writeAsBytes(bytes, flush: true);
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Combined PDF saved successfully.')),
          );
        }
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not combine PDFs: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Mistake My Rule'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 20),
          const Icon(Icons.picture_as_pdf, size: 72),
          const SizedBox(height: 14),
          const Text(
            'My Mistake My Rule',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'PDF editing & combining — simple, private and focused.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 28),
          FilledButton.icon(
            onPressed: _busy ? null : pickPdfs,
            icon: const Icon(Icons.folder_open),
            label: const Text('Select PDF(s)'),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            onPressed: (_busy || _pdfs.isEmpty) ? null : combinePdfs,
            icon: const Icon(Icons.merge_type),
            label: const Text('Combine PDFs'),
          ),
          const SizedBox(height: 24),
          if (_pdfs.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text('${_pdfs.length} PDF(s) selected',
                        style: const TextStyle(fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    ..._pdfs.map((f) => ListTile(
                      dense: true,
                      leading: const Icon(Icons.picture_as_pdf),
                      title: Text(f.path.split(Platform.pathSeparator).last),
                    )),
                  ],
                ),
              ),
            ),
          const SizedBox(height: 20),
          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'My Rule workflow:\n'
                '• Keep teacher-taught study material\n'
                '• Remove Telegram slides\n'
                '• Remove homework / Thank You / extra slides\n\n'
                'This prototype does not change Android system settings.',
              ),
            ),
          ),
          if (_busy) ...[
            const SizedBox(height: 20),
            const Center(child: CircularProgressIndicator()),
          ],
        ],
      ),
    );
  }
}
