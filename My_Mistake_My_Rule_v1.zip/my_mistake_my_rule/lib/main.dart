import 'dart:io';
import 'dart:typed_data';
import 'dart:ui' as ui;

import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:flutter/rendering.dart';
import 'package:syncfusion_flutter_pdf/pdf.dart';

void main() => runApp(const MyRuleApp());

class MyRuleApp extends StatelessWidget {
  const MyRuleApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'My Mistake My Rule',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.indigo),
        useMaterial3: true,
      ),
      home: const HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  final List<File> _pdfs = [];
  bool _busy = false;

  Future<void> pickPdfs() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      allowMultiple: true,
    );
    if (result == null) return;

    final files = result.paths.whereType<String>().map(File.new).toList();
    setState(() {
      _pdfs
        ..clear()
        ..addAll(files);
    });
  }

  void _movePdf(int index, int direction) {
    final newIndex = index + direction;
    if (newIndex < 0 || newIndex >= _pdfs.length) return;
    setState(() {
      final file = _pdfs.removeAt(index);
      _pdfs.insert(newIndex, file);
    });
  }

  void _removePdf(int index) {
    setState(() => _pdfs.removeAt(index));
  }

  Future<void> _saveBytes({
    required Uint8List bytes,
    required String fileName,
    required String dialogTitle,
    String extension = 'pdf',
    String mimeType = 'application/pdf',
  }) async {
    // IMPORTANT: file_picker on current Android/iOS versions requires
    // the actual bytes when saveFile() is called.
    await FilePicker.platform.saveFile(
      dialogTitle: dialogTitle,
      fileName: fileName,
      bytes: bytes,
      mimeType: mimeType,
      type: FileType.custom,
      allowedExtensions: [extension],
    );
  }

  Future<void> combinePdfs() async {
    if (_pdfs.isEmpty) return;
    setState(() => _busy = true);

    try {
      final out = PdfDocument();

      for (final file in _pdfs) {
        final bytes = await file.readAsBytes();
        final doc = PdfDocument(inputBytes: bytes);

        for (var i = 0; i < doc.pages.count; i++) {
          final page = out.pages.add();
          final template = doc.pages[i].createTemplate();
          page.graphics.drawPdfTemplate(template, Offset.zero);
        }

        doc.dispose();
      }

      final bytes = Uint8List.fromList(await out.save());
      out.dispose();

      await _saveBytes(
        bytes: bytes,
        fileName: 'My_Rule_Combined.pdf',
        dialogTitle: 'Save combined PDF',
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Combined PDF saved successfully.')),
        );
      }
    } catch (e) {
      _showError('Could not combine PDFs: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  Future<void> editPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: ['pdf'],
      allowMultiple: false,
    );
    if (result == null || result.paths.isEmpty) return;

    final file = File(result.paths.first!);
    if (!mounted) return;

    await Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => PdfEditorPage(file: file)),
    );
  }

  Future<void> pickImagesToPdf() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: true,
    );
    if (result == null) return;

    setState(() => _busy = true);
    try {
      final out = PdfDocument();

      for (final platformFile in result) {
        final path = platformFile.path;
        if (path == null) continue;

        final bytes = await File(path).readAsBytes();
        final image = PdfBitmap(bytes);
        final page = out.pages.add();

        final pageSize = page.getClientSize();
        final imageSize = Size(
          image.width.toDouble(),
          image.height.toDouble(),
        );

        final scale = _fitScale(imageSize, pageSize);
        final drawWidth = imageSize.width * scale;
        final drawHeight = imageSize.height * scale;
        final left = (pageSize.width - drawWidth) / 2;
        final top = (pageSize.height - drawHeight) / 2;

        page.graphics.drawImage(
          image,
          Rect.fromLTWH(left, top, drawWidth, drawHeight),
        );
      }

      final bytes = Uint8List.fromList(await out.save());
      out.dispose();

      await _saveBytes(
        bytes: bytes,
        fileName: 'My_Rule_Images.pdf',
        dialogTitle: 'Save image PDF',
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Images converted to PDF.')),
        );
      }
    } catch (e) {
      _showError('Could not create PDF from images: $e');
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  double _fitScale(Size source, Size target) {
    if (source.width <= 0 || source.height <= 0) return 1;
    return (target.width / source.width).clamp(
      0.0,
      target.height / source.height,
    );
  }

  void _showError(String message) {
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(message)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('My Mistake My Rule'),
        centerTitle: true,
      ),
      body: ListView(
        padding: const EdgeInsets.all(20),
        children: [
          const SizedBox(height: 10),
          const Icon(Icons.auto_awesome, size: 64),
          const SizedBox(height: 12),
          const Text(
            'My Mistake My Rule',
            textAlign: TextAlign.center,
            style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            'PDF tools + photo editor — simple, private and focused.',
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 24),

          FilledButton.icon(
            onPressed: _busy ? null : pickPdfs,
            icon: const Icon(Icons.picture_as_pdf),
            label: const Text('Select PDF(s)'),
          ),
          const SizedBox(height: 10),

          OutlinedButton.icon(
            onPressed: (_busy || _pdfs.isEmpty) ? null : combinePdfs,
            icon: const Icon(Icons.merge_type),
            label: const Text('Combine PDFs'),
          ),
          const SizedBox(height: 10),

          OutlinedButton.icon(
            onPressed: _busy ? null : editPdf,
            icon: const Icon(Icons.edit_document),
            label: const Text('Edit PDF / Delete Pages'),
          ),
          const SizedBox(height: 10),

          OutlinedButton.icon(
            onPressed: _busy ? null : pickImagesToPdf,
            icon: const Icon(Icons.collections),
            label: const Text('Images → PDF'),
          ),
          const SizedBox(height: 10),

          OutlinedButton.icon(
            onPressed: _busy
                ? null
                : () {
                    Navigator.of(context).push(
                      MaterialPageRoute(
                        builder: (_) => const PhotoEditorPage(),
                      ),
                    );
                  },
            icon: const Icon(Icons.photo_edit),
            label: const Text('Photo Editor'),
          ),

          const SizedBox(height: 20),

          if (_pdfs.isNotEmpty)
            Card(
              child: Padding(
                padding: const EdgeInsets.all(14),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: Text(
                            '${_pdfs.length} PDF(s) selected',
                            style: const TextStyle(
                              fontWeight: FontWeight.bold,
                            ),
                          ),
                        ),
                        TextButton(
                          onPressed: _busy
                              ? null
                              : () => setState(_pdfs.clear),
                          child: const Text('Clear'),
                        ),
                      ],
                    ),
                    const SizedBox(height: 6),
                    ...List.generate(_pdfs.length, (index) {
                      final file = _pdfs[index];
                      return ListTile(
                        dense: true,
                        contentPadding: EdgeInsets.zero,
                        leading: CircleAvatar(
                          child: Text('${index + 1}'),
                        ),
                        title: Text(
                          file.path.split(Platform.pathSeparator).last,
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                        trailing: Row(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            IconButton(
                              tooltip: 'Move up',
                              onPressed: _busy || index == 0
                                  ? null
                                  : () => _movePdf(index, -1),
                              icon: const Icon(Icons.arrow_upward),
                            ),
                            IconButton(
                              tooltip: 'Move down',
                              onPressed:
                                  _busy || index == _pdfs.length - 1
                                      ? null
                                      : () => _movePdf(index, 1),
                              icon: const Icon(Icons.arrow_downward),
                            ),
                            IconButton(
                              tooltip: 'Remove',
                              onPressed: _busy
                                  ? null
                                  : () => _removePdf(index),
                              icon: const Icon(Icons.delete_outline),
                            ),
                          ],
                        ),
                      );
                    }),
                  ],
                ),
              ),
            ),

          const SizedBox(height: 16),

          const Card(
            child: Padding(
              padding: EdgeInsets.all(16),
              child: Text(
                'My Rule workflow:\n'
                '• Keep teacher-taught study material\n'
                '• Remove Telegram slides\n'
                '• Remove homework / Thank You / extra slides\n\n'
                'Files are processed locally by the app; no account is required for these tools.',
              ),
            ),
          ),

          if (_busy) ...[
            const SizedBox(height: 20),
            const Center(child: CircularProgressIndicator()),
          ],
        ],
      ),
    );
  }
}

class PdfEditorPage extends StatefulWidget {
  const PdfEditorPage({super.key, required this.file});

  final File file;

  @override
  State<PdfEditorPage> createState() => _PdfEditorPageState();
}

class _PdfEditorPageState extends State<PdfEditorPage> {
  PdfDocument? _document;
  final Set<int> _removedPages = {};
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      final bytes = await widget.file.readAsBytes();
      final document = PdfDocument(inputBytes: bytes);
      if (!mounted) {
        document.dispose();
        return;
      }
      setState(() => _document = document);
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not open PDF: $e')),
        );
      }
    }
  }

  Future<void> _saveEdited() async {
    final document = _document;
    if (document == null || document.pages.count == 0) return;

    setState(() => _busy = true);
    try {
      final indexes = _removedPages.toList()
        ..sort((a, b) => b.compareTo(a));

      for (final index in indexes) {
        if (index >= 0 && index < document.pages.count) {
          document.pages.removeAt(index);
        }
      }

      final bytes = Uint8List.fromList(await document.save());

      await FilePicker.platform.saveFile(
        dialogTitle: 'Save edited PDF',
        fileName: 'My_Rule_Edited.pdf',
        bytes: bytes,
        mimeType: 'application/pdf',
        type: FileType.custom,
        allowedExtensions: const ['pdf'],
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Edited PDF saved successfully.')),
        );
        Navigator.of(context).pop();
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save edited PDF: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _busy = false);
    }
  }

  @override
  void dispose() {
    _document?.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final document = _document;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Edit PDF'),
        actions: [
          IconButton(
            tooltip: 'Save edited PDF',
            onPressed: _busy || document == null ? null : _saveEdited,
            icon: const Icon(Icons.save),
          ),
        ],
      ),
      body: document == null
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                const Text(
                  'Select pages to remove',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 6),
                Text('${document.pages.count} page(s)'),
                const SizedBox(height: 12),
                ...List.generate(document.pages.count, (index) {
                  final removed = _removedPages.contains(index);
                  return Card(
                    child: CheckboxListTile(
                      value: removed,
                      onChanged: _busy
                          ? null
                          : (value) {
                              setState(() {
                                if (value == true) {
                                  _removedPages.add(index);
                                } else {
                                  _removedPages.remove(index);
                                }
                              });
                            },
                      title: Text('Page ${index + 1}'),
                      subtitle: Text(
                        removed ? 'Will be removed' : 'Will be kept',
                      ),
                      secondary: Icon(
                        removed
                            ? Icons.remove_circle_outline
                            : Icons.picture_as_pdf,
                      ),
                    ),
                  );
                }),
                const SizedBox(height: 12),
                FilledButton.icon(
                  onPressed: _busy || _removedPages.isEmpty
                      ? null
                      : _saveEdited,
                  icon: const Icon(Icons.save),
                  label: const Text('Save edited PDF'),
                ),
                if (_busy) const LinearProgressIndicator(),
              ],
            ),
    );
  }
}

class PhotoEditorPage extends StatefulWidget {
  const PhotoEditorPage({super.key});

  @override
  State<PhotoEditorPage> createState() => _PhotoEditorPageState();
}

class _PhotoEditorPageState extends State<PhotoEditorPage> {
  final GlobalKey _previewKey = GlobalKey();

  Uint8List? _imageBytes;
  double _brightness = 0;
  double _contrast = 1;
  double _saturation = 1;
  double _rotation = 0;
  bool _flipX = false;
  bool _flipY = false;
  bool _saving = false;

  Future<void> _pickImage() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.image,
      allowMultiple: false,
    );
    if (result == null || result.files.isEmpty) return;

    final file = result.files.first;
    final bytes = await file.readAsBytes();

    setState(() {
      _imageBytes = bytes;
      _brightness = 0;
      _contrast = 1;
      _saturation = 1;
      _rotation = 0;
      _flipX = false;
      _flipY = false;
    });
  }

  Future<void> _savePhoto() async {
    if (_imageBytes == null || _saving) return;

    setState(() => _saving = true);
    try {
      await Future<void>.delayed(const Duration(milliseconds: 50));

      final boundary =
          _previewKey.currentContext?.findRenderObject()
              as RenderRepaintBoundary?;
      if (boundary == null) {
        throw Exception('Photo preview is not ready.');
      }

      final image = await boundary.toImage(pixelRatio: 2.0);
      final byteData = await image.toByteData(format: ui.ImageByteFormat.png);
      image.dispose();

      if (byteData == null) {
        throw Exception('Could not create image bytes.');
      }

      final bytes = byteData.buffer.asUint8List();

      await FilePicker.platform.saveFile(
        dialogTitle: 'Save edited photo',
        fileName: 'My_Rule_Edited.png',
        bytes: bytes,
        mimeType: 'image/png',
        type: FileType.custom,
        allowedExtensions: const ['png'],
      );

      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Edited photo saved successfully.')),
        );
      }
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Could not save photo: $e')),
        );
      }
    } finally {
      if (mounted) setState(() => _saving = false);
    }
  }

  ColorFilter _photoFilter() {
    final b = _brightness * 255;
    final c = _contrast;
    final s = _saturation;

    final sr = 0.213 * (1 - s);
    final sg = 0.715 * (1 - s);
    final sb = 0.072 * (1 - s);

    return ColorFilter.matrix([
      c * (sr + s), c * sg, c * sb, 0, b,
      c * sr, c * (sg + s), c * sb, 0, b,
      c * sr, c * sg, c * (sb + s), 0, b,
      0, 0, 0, 1, 0,
    ]);
  }

  Widget _preview() {
    if (_imageBytes == null) {
      return const Center(
        child: Text('Choose a photo to start editing.'),
      );
    }

    return RepaintBoundary(
      key: _previewKey,
      child: Container(
        color: Colors.black,
        alignment: Alignment.center,
        child: ColorFiltered(
          colorFilter: _photoFilter(),
          child: Transform(
            alignment: Alignment.center,
            transform: Matrix4.identity()
              ..rotateZ(_rotation)
              ..scale(
                _flipX ? -1.0 : 1.0,
                _flipY ? -1.0 : 1.0,
              ),
            child: Image.memory(
              _imageBytes!,
              fit: BoxFit.contain,
            ),
          ),
        ),
      ),
    );
  }

  Widget _slider({
    required String label,
    required double value,
    required double min,
    required double max,
    required ValueChanged<double> onChanged,
  }) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('$label: ${value.toStringAsFixed(2)}'),
        Slider(
          value: value,
          min: min,
          max: max,
          onChanged: _imageBytes == null ? null : onChanged,
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Photo Editor'),
        actions: [
          IconButton(
            tooltip: 'Save',
            onPressed: _imageBytes == null || _saving ? null : _savePhoto,
            icon: const Icon(Icons.save),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          SizedBox(
            height: 300,
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: _preview(),
            ),
          ),
          const SizedBox(height: 14),
          FilledButton.icon(
            onPressed: _saving ? null : _pickImage,
            icon: const Icon(Icons.photo_library),
            label: Text(_imageBytes == null ? 'Choose Photo' : 'Change Photo'),
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceEvenly,
            children: [
              IconButton(
                tooltip: 'Rotate left',
                onPressed: _imageBytes == null
                    ? null
                    : () => setState(
                          () => _rotation -= 1.57079632679,
                        ),
                icon: const Icon(Icons.rotate_left),
              ),
              IconButton(
                tooltip: 'Rotate right',
                onPressed: _imageBytes == null
                    ? null
                    : () => setState(
                          () => _rotation += 1.57079632679,
                        ),
                icon: const Icon(Icons.rotate_right),
              ),
              IconButton(
                tooltip: 'Flip horizontal',
                onPressed: _imageBytes == null
                    ? null
                    : () => setState(() => _flipX = !_flipX),
                icon: const Icon(Icons.flip),
              ),
              IconButton(
                tooltip: 'Flip vertical',
                onPressed: _imageBytes == null
                    ? null
                    : () => setState(() => _flipY = !_flipY),
                icon: const Icon(Icons.flip_camera_android),
              ),
            ],
          ),
          _slider(
            label: 'Brightness',
            value: _brightness,
            min: -1,
            max: 1,
            onChanged: (v) => setState(() => _brightness = v),
          ),
          _slider(
            label: 'Contrast',
            value: _contrast,
            min: 0.2,
            max: 2,
            onChanged: (v) => setState(() => _contrast = v),
          ),
          _slider(
            label: 'Saturation',
            value: _saturation,
            min: 0,
            max: 2,
            onChanged: (v) => setState(() => _saturation = v),
          ),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: _imageBytes == null || _saving ? null : _savePhoto,
            icon: const Icon(Icons.download),
            label: const Text('Save Edited Photo'),
          ),
          if (_saving) const LinearProgressIndicator(),
        ],
      ),
    );
  }
}
